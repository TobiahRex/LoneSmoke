(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	var _stringify = __webpack_require__(1);

	var _stringify2 = _interopRequireDefault(_stringify);

	var _handleUserEmail = __webpack_require__(2);

	var _handleUserEmail2 = _interopRequireDefault(_handleUserEmail);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	/* eslint-disable global-require, import/imports-first, no-console, no-unused-expressions */
	if (!global._babelPolyfill) __webpack_require__(4);

	// import { startDB } from './db/mongo/connection';

	module.exports.discount = function (event, context, cb) {
	  console.log('\nEVENT: ', event);
	  // 3a. Send user a 200 status code and an email that says - "Thank you for signing up with LoneSmoke.  Show this email when you pay and receive 10% off your meal.".
	  (0, _handleUserEmail2.default)(event).then(function (results) {
	    console.log('\n >> FINAL Lambda SUCCESS response: \n', (0, _stringify2.default)(results, null, 2));
	    context.succeed && context.succeed(results);
	    cb(null, results);
	  }).catch(function (error) {
	    console.log('\nFINAL Lambda ERROR: \n', (0, _stringify2.default)(error, null, 2));
	    context.error && context.error(error);
	  });
	};

/***/ }),
/* 1 */
/***/ (function(module, exports) {

	module.exports = require("babel-runtime/core-js/json/stringify");

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _stringify = __webpack_require__(1);

	var _stringify2 = _interopRequireDefault(_stringify);

	var _promise = __webpack_require__(3);

	var _promise2 = _interopRequireDefault(_promise);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	exports.default = function (event) {
	  return new _promise2.default(function (resolve) {
	    console.log('\n@handleUserEmail: \n event: ', (0, _stringify2.default)(event, null, 2));
	    resolve();
	  });
	};
	// 1a. check users email in the database.
	// User.find({  })
	// 1b. if a matching email is found - respond with an email that says - You've already received a discount for signing up.
	// 1c. If there is no match found...
	// 2a. Save the user's email into the database.
	// 2b. Upon completion - send users email to market hero.
	// 2c. Attach a tag to the user that identifies them as LoneSmoke customer.
	// 2d. If both requests are successful...

/***/ }),
/* 3 */
/***/ (function(module, exports) {

	module.exports = require("babel-runtime/core-js/promise");

/***/ }),
/* 4 */
/***/ (function(module, exports) {

	module.exports = require("babel-polyfill");

/***/ })
/******/ ])));